// 代码整理：懒人之家

var timerID = null;
var timerRunning = false;
// Called by both onLoad in BODY tag, and Resume button.
function startclock () 
   {
   // Make sure the clock is stopped
   stopclock();
   time();
   }
// Kills clock.
function stopclock ()
   {
   if(timerRunning)
      clearTimeout(timerID);
   timerRunning = false;
   }
function time ()
   {
   var now = new Date();
   var yr = now.getFullYear()+"年";
   var mName = now.getMonth() + 1;
   var dName = now.getDay() + 1;
   var dayNr = ((now.getDate()<10) ? "0" : "")+ now.getDate()+"日";
   var ampm = (now.getHours() >= 12) ? " Pm" : " Am"
   var hours = now.getHours();
        /*  hours = ((hours > 12) ? hours - 12 : hours); */
   var minutes = ((now.getMinutes() < 10) ? ":0" : ":") + now.getMinutes();
   var seconds = ((now.getSeconds() < 10) ? ":0" : ":") + now.getSeconds();
   if(dName==1) Day = "星期日";
   if(dName==2) Day = "星期一";
   if(dName==3) Day = "星期二";
   if(dName==4) Day = "星期三";
   if(dName==5) Day = "星期四";
   if(dName==6) Day = "星期五";
   if(dName==7) Day = "星期六";
   if(mName==1) Month="1月";
   if(mName==2) Month="2月";
   if(mName==3) Month="3月";
   if(mName==4) Month="4月";
   if(mName==5) Month="5月";
   if(mName==6) Month="6月";
   if(mName==7) Month="7月";
   if(mName==8) Month="8月";
   if(mName==9) Month="9月";
   if(mName==10) Month="10月";
   if(mName==11) Month="11月";
   if(mName==12) Month="12月";
   // String to display current date.
   var DayDateTime=(" "
       + Day
       + "     "
       + yr
	   +"/"
       + Month
       + "/"
       + dayNr
       + ""
       + "     "
       + hours
       + minutes
       + seconds
       + " "
        );
   // Displays Day-Date-Time on the staus bar.
   document.clock.face.value=DayDateTime;
   timerID = setTimeout("time()",1000);
   timerRunning = true;
   }
// Stops clock and clears status bar.
function clearStatus()
   {
   if(timerRunning)
      clearTimeout(timerID);
   timerRunning = false;
   window.status=" ";   
   }
// -- End Hiding Here -->